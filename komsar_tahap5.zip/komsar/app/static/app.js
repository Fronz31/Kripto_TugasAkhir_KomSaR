document.addEventListener("submit", function (e) {
  var msg = e.target.getAttribute("data-confirm");
  if (msg && !window.confirm(msg)) e.preventDefault();
});
var kind = document.getElementById("kind-filter");
var target = document.getElementById("delivery-select");
if (kind && target) {
  var apply = function () {
    Array.prototype.forEach.call(target.options, function (o) {
      var hide = kind.value && o.getAttribute("data-kind") !== kind.value;
      o.hidden = hide; o.disabled = hide;
    });
    if (target.selectedOptions[0] && target.selectedOptions[0].disabled) target.selectedIndex = -1;
  };
  kind.addEventListener("change", apply); apply();
}
