import io
from pathlib import Path

from flask import Blueprint, abort, flash, g, render_template, request, send_file

from ..errors import KomSaRError
from ._helpers import login_required, svc

bp = Blueprint("decrypt", __name__)
KIND_CHOICES = [("", "Semua jenis"), ("text", "Pesan Biasa"), ("important_text", "Pesan Penting"),
                ("file", "File"), ("image", "Gambar"), ("asset", "Aset Penting")]
INLINE_IMAGES = {"image/png", "image/jpeg", "image/gif", "image/webp", "image/bmp"}


@bp.route("/decrypt", methods=["GET", "POST"])
@login_required
def center():
    s = svc()
    result, token = None, None
    chosen = request.values.get("d", "")
    if request.method == "POST":
        chosen = request.form.get("delivery_id", "")
        try:
            result = s.decryption.open(g.user, chosen, request.form.get("user_id", ""),
                                       expected_kind=request.form.get("kind") or None)
            token = s.cache.remember(g.user.id, chosen, result)
        except KomSaRError as e:
            flash(str(e), "error")                      # tanpa plaintext parsial
    return render_template("decrypt.html", items=s.messaging.inbox(g.user), kinds=KIND_CHOICES,
                           chosen=chosen, result=result, token=token, inline_images=INLINE_IMAGES)


@bp.route("/decrypt/file/<token>")
@login_required
def download(token):
    entry = svc().cache.get_file(token, g.user.id)
    if entry is None:
        abort(404)
    inline = request.args.get("inline") == "1" and entry["mime"] in INLINE_IMAGES
    return send_file(io.BytesIO(entry["data"]), mimetype=entry["mime"] if inline else "application/octet-stream",
                     as_attachment=not inline, download_name=entry["name"])


def _own_delivery(delivery_id):
    d = svc().repo.get_delivery(delivery_id)
    if d is None or d.recipient_pk != g.user.id:
        abort(404)
    return d


@bp.route("/delivery/<delivery_id>/stego")
@login_required
def stego(delivery_id):
    d = _own_delivery(delivery_id)
    return send_file(d.stego_path, mimetype="image/png", as_attachment=True,
                     download_name=f"stego_{delivery_id[:8]}.png")


@bp.route("/delivery/<delivery_id>/cipher")
@login_required
def cipher(delivery_id):
    s = svc()
    d = _own_delivery(delivery_id)
    m = s.repo.get_message(d.message_id)
    if m.file_id:
        return send_file(s.repo.get_file(m.file_id).enc_path, mimetype="application/octet-stream",
                         as_attachment=True, download_name=f"cipher_{delivery_id[:8]}.enc")
    return send_file(io.BytesIO(m.ciphertext), mimetype="application/octet-stream", as_attachment=True,
                     download_name=f"cipher_{delivery_id[:8]}.bin")
