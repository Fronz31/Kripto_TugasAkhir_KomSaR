"""Cache hasil dekripsi di MEMORI proses (bukan database, bukan log, bukan cookie).

Dipakai agar isi pesan tetap tampil di chatbox setelah dekripsi berhasil dan agar file hasil dekripsi
dapat diunduh. Dibersihkan saat logout; file kedaluwarsa otomatis.
"""
import secrets
import time
from collections import OrderedDict

TTL_SECONDS = 600
MAX_FILES = 10


class ResultCache:
    def __init__(self):
        self.texts: dict[tuple[int, str], str] = {}
        self.files: "OrderedDict[str, dict]" = OrderedDict()

    def remember(self, user_pk: int, delivery_id: str, result):
        """Teks -> simpan per delivery (None). File -> simpan sementara, kembalikan token unduh."""
        if result.text is not None:
            self.texts[(user_pk, delivery_id)] = result.text
            return None
        self._purge()
        token = secrets.token_urlsafe(16)
        self.files[token] = {"user_pk": user_pk, "name": result.filename, "mime": result.mime,
                             "data": result.data, "expires": time.time() + TTL_SECONDS}
        while len(self.files) > MAX_FILES:
            self.files.popitem(last=False)
        return token

    def get_text(self, user_pk: int, delivery_id: str):
        return self.texts.get((user_pk, delivery_id))

    def get_file(self, token: str, user_pk: int):
        self._purge()
        entry = self.files.get(token)
        return entry if entry and entry["user_pk"] == user_pk else None

    def clear_user(self, user_pk: int) -> None:
        self.texts = {k: v for k, v in self.texts.items() if k[0] != user_pk}
        for t in [t for t, e in self.files.items() if e["user_pk"] == user_pk]:
            del self.files[t]

    def _purge(self) -> None:
        now = time.time()
        for t in [t for t, e in self.files.items() if e["expires"] < now]:
            del self.files[t]
